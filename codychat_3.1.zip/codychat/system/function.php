<?php
/**
* Codychat
*
* @package Codychat
* @author www.boomcoding.com
* @copyright 2019
* @terms any use of this script without a legal license is prohibited
* all the content of Codychat is the propriety of BoomCoding and Cannot be 
* used for another project.
*/
function getIp(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $cloud =   @$_SERVER["HTTP_CF_CONNECTING_IP"];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($cloud, FILTER_VALIDATE_IP)) {
        $ip = $cloud;
    }
    else if(filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP)){
        $ip = $forward;
    }
    else{
        $ip = $remote;
    }
    return escape($ip);
}
function boomTemplate($getpage, $boom = '') {
	global $data, $lang, $mysqli, $cody;
    $page = BOOM_PATH . '/system/' . $getpage . '.php';
    $structure = '';
    ob_start();
    require($page);
    $structure = ob_get_contents();
    ob_end_clean();
    return $structure;
}
function calHour($h){
	return time() - ($h * 3600);
}
function calWeek($w){
	return time() - ( 3600 * 24 * 7 * $w);
}
function calmonth($m){
	return time() - ( 3600 * 24 * 30 * $m);
}
function calDay($d){
	return time() - ($d * 86400);
}
function calMinutes($min){
	return time() - ($min * 60);
}
function calHourUp($h){
	return time() + ($h * 3600);
}
function calWeekUp($w){
	return time() + ( 3600 * 24 * 7 * $w);
}
function calmonthUp($m){
	return time() + ( 3600 * 24 * 30 * $m);
}
function calDayUp($d){
	return time() + ($d * 86400);
}
function calMinutesUp($min){
	return time() + ($min * 60);
}
function boomFormat($txt){
	$count = substr_count($txt, "\n" );
	if($count > 20){
		return $txt;
	}
	else {
		return nl2br($txt);
	}
}
function boomFileVersion(){
	global $data;
	if($data['bbfv'] > 1.0){
		return '?v=' . $data['bbfv'];
	}
	return '';
}
function boomNull($val){
	if(is_Null($val)){
		return 0;
	}
	else {
		return $val;
	}
}
function embedMode(){
	global $data;
	if(isset($_GET['embed'])){
		return true;
	}
}
function embedCode(){
	global $data;
	if(isset($_GET['embed'])){
		return 1;
	}
	else {
		return 0;
	}
}
function myavatar($a){
	global $data;
	$path =  '/avatar/';
	if(stripos($a, 'default') !== false){
		$path =  '/default_images/';
	}
	return $data['domain'] . $path . $a;
}
function myCover($a){
	global $data;
	return $data['domain'] . '/cover/' . $a;
}
function getCover($user){
	global $data;
	if(userHaveCover($user)){
		return 'style="background-image: url(' . myCover($user['user_cover']) . ');"';
	}
}
function coverClass($user){
	global $data;
	if(userHaveCover($user)){
		return 'cover_size';
	}
}
function userHaveCover($user){
	global $data;
	if($user['user_cover'] != ''){
		return true;
	}
}
function getIcon($icon, $c){
	global $data, $lang;
	return '<img class="' . $c . '" src="' . $data['domain'] . '/default_images/icons/' . $icon . boomFileVersion() . '"/>';
}
function boomCode($code, $custom = array()){
	$def = array('code'=> $code);
	$res = array_merge($def, $custom);
	return json_encode( $res, JSON_UNESCAPED_UNICODE);
}
function profileAvatar($a){
	global $data;
	$path =  '/avatar/';
	if(stripos($a, 'default') !== false){
		$path =  '/default_images/';
	}
	return 'href="' . $data['domain'] . $path  . $a . '" src="' . $data['domain'] . $path  . $a . '"';
}
function boomUserTheme($user){
	global $data;
	if($user['user_theme'] == 'system'){
		return $data['default_theme'];
	}
	else {
		return $user['user_theme'];
	}
}
function linkAvatar($a){
	if(preg_match('@^https?://@i', $a)){
		return true;
	}
}
function escape($t){
	global $mysqli;
	return $mysqli->real_escape_string(trim(htmlspecialchars($t, ENT_QUOTES)));
}
function boomSanitize($t){
	global $mysqli;
	$t = str_replace(array('\\', '/', '.', '<', '>', '%', '#'), '', $t);
	return $mysqli->real_escape_string(trim(htmlspecialchars($t, ENT_QUOTES)));
}
function softEscape($t){
	global $mysqli;
	$atags = '<a><p><h1><h2><h3><h4><img><b><strong><br><ul><li><div><i><span><u><th><td><tr><table><strike><small><ol><hr><font><center><blink><marquee>';
	$t = strip_tags($t, $atags);
	return $mysqli->real_escape_string(trim($t));
}
function systemReplace($text){
	global $lang;
	$text = str_replace('%bcquit%', $lang['leave_message'], $text);
	$text = str_replace('%bcjoin%', $lang['join_message'], $text);
	$text = str_replace('%bcclear%', $lang['clear_message'], $text);
	$text = str_replace('%spam%', $lang['spam_content'], $text);
	return $text;
}
function systemSpecial($content, $type, $custom = array()){
	global $data, $lang;
	$def = array(
		'content'=> $content,
		'type'=> $type,
		'delete'=> 1,
		'title'=> $lang['default_title'],
		'icon'=> 'default_system.png',
	);
	$template = array_merge($def, $custom);
	return boomTemplate('element/system_log', $template);
}
function specialLogIcon($icon){
	global $data;
	return $data['domain'] . '/default_images/special/' . $icon . boomFileVersion();
}
function userDetails($id){
	global $mysqli;
	$user = array();
	$getuser = $mysqli->query("SELECT * FROM boom_users WHERE user_id = '$id'");
	if($getuser->num_rows > 0){
		$user = $getuser->fetch_assoc();
	}
	return $user;
}
function ownAvatar($i){
	global $data;
	if($i == $data['user_id']){
		return 'glob_av';
	}
	return '';
}
function chatAction($room, $action = 1){
	global $mysqli, $data;
	$addthis = '';
	if($action == 1){
		$addthis = ", room_action = '" . time() . "'";
	}
	$mysqli->query("UPDATE boom_rooms SET rcaction = rcaction + 1 $addthis WHERE room_id = '$room'");
}
function userPostChat($content, $custom = array()){
	global $mysqli, $data;
	$def = array(
		'hunter'=> $data['user_id'],
		'room'=> $data['user_roomid'],
		'color'=> escape($data['bccolor'] . ' ' . $data['bcbold']),
		'type'=> 'public',
		'rank'=> 99,
		'snum'=> '',
	);
	$c = array_merge($def, $data, $custom);
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, log_rank, snum, tcolor) VALUES ('" . time() . "', '{$c['hunter']}', '$content', '{$c['room']}', '{$c['type']}', '{$c['rank']}', '{$c['snum']}', '{$c['color']}')");
	$last_id = $mysqli->insert_id;
	chatAction($data['user_roomid']);
	if(!empty($c['snum'])){
		$user_post = array(
			'post_id'=> $last_id,
			'type'=> $c['type'],
			'post_date'=> time(),
			'tcolor'=> $c['color'],
			'log_rank'=> $c['rank'],
			'post_message'=> $content,
		);
		$post = array_merge($c, $user_post);
		if(!empty($post)){
			return createLog($data, $post);
		}
	}
}
function userPostChatFile($content, $file_name, $type, $file_name2 = ''){
	global $mysqli, $data;
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, file) VALUES ('" . time() . "', '{$data['user_id']}', '$content', '{$data['user_roomid']}', 'public', '1')");
	$rel = $mysqli->insert_id;
	chatAction($data['user_roomid']);
	if($file_name2 != ''){
		$mysqli->query("INSERT INTO `boom_upload` (file_name, date_sent, file_user, file_zone, file_type, relative_post) VALUES
		('$file_name', '" . time() . "', '{$data['user_id']}', 'chat', '$type', '$rel'),
		('$file_name2', '" . time() . "', '{$data['user_id']}', 'chat', '$type', '$rel')
		");
	}
	else {
		$mysqli->query("INSERT INTO `boom_upload` (file_name, date_sent, file_user, file_zone, file_type, relative_post) VALUES ('$file_name', '" . time() . "', '{$data['user_id']}', 'chat', '$type', '$rel')");
	}
	return true;
}
function systemPostChat($room, $content, $custom = array()){
	global $mysqli, $data;
	$def = array(
		'type'=> 'system',
		'color'=> 'chat_system',
		'rank'=> 99,
	);
	$post = array_merge($def, $custom);
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, log_rank, tcolor) VALUES ('" . time() . "', '{$data['system_id']}', '$content', '$room', '{$post['type']}', '{$post['rank']}', '{$post['color']}')");
	chatAction($room);
	return true;
}
function botPostChat($id, $room, $content, $custom = array()){
	global $mysqli, $data;
	$def = array(
		'type'=> 'public',
		'color'=> '',
		'rank'=> 99,
	);
	$post = array_merge($def, $custom);
	$mysqli->query("INSERT INTO `boom_chat` (post_date, user_id, post_message, post_roomid, type, log_rank, tcolor) VALUES ('" . time() . "', '$id', '$content', '$room', '{$post['type']}', '{$post['rank']}', '{$post['color']}')");
	chatAction($room);	
	return true;
}
function postPrivate($from, $to, $content, $snum = ''){
	global $mysqli, $data;
	$mysqli->query("INSERT INTO `boom_private` (time, target, hunter, message) VALUES ('" . time() . "', '$to', '$from', '$content')");
	$last_id = $mysqli->insert_id;
	if($to != $from){
		$mysqli->query("UPDATE boom_users SET pcount = pcount + 1 WHERE user_id = '$to'");
	}
	if($snum != ''){
		$user_post = array(
			'id'=> $last_id,
			'time'=> time(),
			'message'=> $content,
		);
		$post = array_merge($data, $user_post);
		if(!empty($post)){
			return privateLog($post, 1);
		}
	}
}
function postPrivateContent($from, $to, $content){
	global $mysqli, $data;
	$mysqli->query("INSERT INTO `boom_private` (time, target, hunter, message, file) VALUES ('" . time() . "', '$to', '$from', '$content', 1)");
	$rel = $mysqli->insert_id;
	$mysqli->query("UPDATE boom_users SET pcount = pcount + 1 WHERE user_id = '$from' OR user_id = '$to'");
	return true;
}
function userPostPrivateFile($content, $target, $file_name, $type){
	global $mysqli, $data;
	$mysqli->query("INSERT INTO `boom_private` (time, target, hunter, message, file) VALUES ('" . time() . "', '$target', '{$data['user_id']}', '$content', 1)");
	$rel = $mysqli->insert_id;
	$mysqli->query("UPDATE boom_users SET pcount = pcount + 1 WHERE user_id = '{$data['user_id']}' OR user_id = '$target'");
	$mysqli->query("INSERT INTO `boom_upload` (file_name, date_sent, file_user, file_zone, file_type, relative_post) VALUES ('$file_name', '" . time() . "', '{$data['user_id']}', 'private', '$type', '$rel')");
	return true;
}
function getFriendList($id, $type = 0){
	global $mysqli;
	$friend_list = array();
	$find_friend = $mysqli->query("SELECT target FROM boom_friends WHERE hunter = '$id' AND status = '3'");
	if($find_friend->num_rows > 0){
		while($find = $find_friend->fetch_assoc()){
			array_push($friend_list, $find['target']);
		}
		if($type == 1){
			array_push($friend_list, $id);
		}
	}
	return $friend_list;
}
function getRankList($rank){
	global $mysqli;
	$list = array();
	$find_list = $mysqli->query("SELECT user_id FROM boom_users WHERE user_rank = '$rank'");
	if($find_list->num_rows > 0){
		while($find = $find_list->fetch_assoc()){
			array_push($list, $find['user_id']);
		}
	}
	return $list;
}
function getStaffList(){
	global $mysqli;
	$list = array();
	$find_list = $mysqli->query("SELECT user_id FROM boom_users WHERE user_rank >= 8");
	if($find_list->num_rows > 0){
		while($find = $find_list->fetch_assoc()){
			array_push($list, $find['user_id']);
		}
	}
	return $list;
}
function boomListNotify($list, $type, $custom = array()){
	global $mysqli, $data;
	if(!empty($list)){
		$values = '';
		foreach($list as $user){
			$def = array(
				'hunter'=> $data['system_id'],
				'room'=> $data['user_roomid'],
				'rank'=> 0,
				'delay'=> 0,
				'reason'=> '',
				'source'=> 'system',
				'sourceid'=> 0,
				'custom' => '',
				'custom2' => '',
			);
			$c = array_merge($def, $custom);
			$values .= "('{$c['hunter']}', '$user', '$type', '" . time() . "', '{$c['source']}', '{$c['sourceid']}', '{$c['rank']}', '{$c['delay']}', '{$c['reason']}', '{$c['custom']}', '{$c['custom2']}'),";
		}
		$values = rtrim($values, ',');
		$mysqli->query("INSERT INTO boom_notification ( notifier, notified, notify_type, notify_date, notify_source, notify_id, notify_rank, notify_delay, notify_reason, notify_custom, notify_custom2) VALUES $values");
		updateListNotify($list);
	}
}
function boomNotify($target, $type, $custom = array()){
	global $mysqli, $data;
	$def = array(
		'hunter'=> $data['system_id'],
		'room'=> $data['user_roomid'],
		'rank'=> 0,
		'delay'=> 0,
		'reason'=> '',
		'source'=> 'system',
		'sourceid'=> 0,
		'custom' => '',
		'custom2' => '',
	);
	$c = array_merge($def, $custom);
	$mysqli->query("INSERT INTO boom_notification ( notifier, notified, notify_type, notify_date, notify_source, notify_id, notify_rank, notify_delay, notify_reason, notify_custom, notify_custom2) 
	VALUE ('{$c['hunter']}', '$target', '$type', '" . time() . "', '{$c['source']}', '{$c['sourceid']}', '{$c['rank']}', '{$c['delay']}', '{$c['reason']}', '{$c['custom']}', '{$c['custom2']}')");
	updateNotify($target); 
}
function updateNotify($id){
	global $mysqli;
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_id = '$id'");
}
function updateListNotify($list){
	global $mysqli;
	if(empty($list)){
		return false;
	}
	$list = implode(", ", $list);
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_id IN ($list)");
}
function updateStaffNotify(){
	global $mysqli;
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE user_rank > 7");
}
function updateAllNotify(){
	global $mysqli;
	$delay = calMinutes(2);
	$mysqli->query("UPDATE boom_users SET naction = naction + 1 WHERE last_action > '$delay'");
}
function createIgnore(){
	global $mysqli, $data, $cody;
	$ignore_list = '';
	$get_ignore = $mysqli->query("SELECT ignored FROM boom_ignore WHERE ignorer = '{$data['user_id']}'");
	while($ignore = $get_ignore->fetch_assoc()){
		$ignore_list .= $ignore['ignored'] . '|';
	}
	$_SESSION[BOOM_PREFIX . 'ignore'] = '|' . $ignore_list;
}
function isIgnored($ignore, $id){
	global $cody;
	if(strpos($ignore, '|' . $id . '|') !== false){
		return true;
	}
}
function getIgnore(){
	global $cody;
	return $_SESSION[BOOM_PREFIX . 'ignore'];
}
function processChatMsg($post) {
	global $data;
	if($post['user_id'] != $data['user_id'] && !preg_match('/http/',$post['post_message'])){
		$post['post_message'] = str_ireplace($data['user_name'], '<span class="my_notice">' . $data['user_name'] . '</span>', $post['post_message']);
	}
	return mb_convert_encoding(systemReplace($post['post_message']), 'UTF-8', 'auto');
}
function processPrivateMsg($post) {
	global $data;
	return mb_convert_encoding(systemReplace($post['message']), 'UTF-8', 'auto');
}
function mainRoom(){
	global $data;
	if($data['user_roomid'] == 1){
		return true;
	}
}
function chatRank($rank, $id){
	global $data;
	if($id != $data['system_id'] && $data['ico'] == 2){
		return systemRank($rank, 'chat_rank');
	}
}
function createLog($data, $post, $ignore = ''){
	global $lang;
	$avmenu = '';
	$log_options = '';
	$gender = '';
	if(isIgnored($ignore, $post['user_id'])){
		return false;
	}
	if(boomAllow($post['log_rank'])){
		return false;
	}
	$avmenu = 'onclick="openAvMenu(this, \''.$post['user_name'].'\','.$post['user_id'].','.$post['user_rank'].', '.$post['user_bot'].');"';
	if(boomAllow(1)){
		if(canDeleteLog() || canDeleteRoomLog()){
			$log_options = '<div onclick="deleteLog(' . $post['post_id'] . ');" class="cclear"><i class="fa fa-times"></i></div>';
		}
		else if(!isSystem($post['user_id'])){
			$log_options = '<div onclick="openReport(' . $post['post_id'] . ', 1);" class="cclear"><i class="fa fa-flag"></i></div>';
		}
	}
	if($data['gender_ico'] > 1){
		$gender = 'avsex ' . sex($post['user_sex']) . ' ';
	}

	return  '<li id="log' . $post['post_id'] . '" data="' . $post['post_id'] . '" class="ch_logs ' . $post['type'] . '">
				<div class="chat_avatar" ' . $avmenu . '>
					<img class="avav ' . $gender . ownAvatar($post['user_id']) . '" src="' . myavatar($post['user_tumb']) . '"/>
				</div>
				<div class="my_text">
					<div class="btable">
							<div class="cname">' . chatRank($post['user_rank'], $post['user_id']) . '<span class="username ' . $post['user_color'] . '">' . $post['user_name'] . '</span></div>
							<div class="cdate">' . chatDate($post['post_date']) . '</div>
							' . $log_options . '
					</div>
					<div class="chat_message ' . $post['tcolor'] . '">' . processChatMsg($post) . '</div>
				</div>
			</li>';	
}
function privateLog($post, $type){
	switch($type){
		case 1:
			return '<li id="priv' . $post['id'] . '">
						<div class="private_logs">
							<div class="private_avatar">
								<img data="' . $post['user_id'] . '" class="get_info avatar_private" src="' . myavatar($post['user_tumb']) . '"/>
							</div>
							<div class="private_content">
								<div class="hunter_private">' . processPrivateMsg($post) . '</div>
								<p class="pdate">' . displayDate($post['time']) . '</p>
							</div>
						</div>
					</li>';
		case 2:
			return '<li id="priv' . $post['id'] . '">
						<div class="private_logs">
							<div class="private_content">
								<div class="target_private">' . processPrivateMsg($post) . '</div>
								<p class="ptdate">' . displayDate($post['time']) . '</p>
							</div>
							<div class="private_avatar">
								<img data="' . $post['user_id'] . '" class="get_info avatar_private" src="' . myavatar($post['user_tumb']) . '"/>
							</div>
						</div>
					</li>';
	}
}
function createUserlist($list, $type = 1){
	global $data, $lang;
	if(!isVisible($list)){
		return false;
	}
	$icon = '';
	$flag = '';
	$muted = '';
	$status = '';
	$gender = '';
	$mood = '';
	if(useFlag($list['country'])){
		$flag = '<div class="user_item_flag"><img src="' . countryFlag($list['country']) . '"/></div>';
	}
	$offline = 'offline';
	$rank_icon = rankIcon($list, 'list_rank');
	$mute_icon = mutedIcon($list, 'list_mute');
	if($data['ico'] > 0 && $rank_icon != ''){
		$icon = '<div class="user_item_icon icrank">' . $rank_icon . '</div>';
	}
	if($mute_icon != ''){
		$muted = '<div class="user_item_icon icmute">' . $mute_icon . '</div>';
	}
	if($data['gender_ico'] > 0){
		$gender = 'avsex ' . sex($list['user_sex']) . ' ';
	}
	if($list['last_action'] > getDelay() || isBot($list)){
		$offline = '';
		$status = getStatus($list['user_status'], 'list_status');
	}
	if(!empty($list['user_mood'])){
		$mood = '<p class="text_xsmall bustate bellips">' . $list['user_mood'] . '</p>';
	}
	return '<div onclick="dropUser(this,'.$list['user_id'].',\''.$list['user_name'].'\','.$list['user_rank'].','.$list['user_bot'].', ' . $type . ');" class="user_item ' . $offline . '">
				<div class="user_item_avatar"><img class="acav ' . $gender . ownAvatar($list['user_id']) . '" src="' . myavatar($list['user_tumb']) . '"/> ' . $status . '</div>
				<div class="user_item_data"><p class="username ' . $list['user_color'] . '">' . $list["user_name"] . '</p>' . $mood . '</div>
				' . $muted . $icon . $flag . '
			</div>
			<div class="drop_list"></div>';
}
function chatDate($date){
	return date("j/m G:i", $date);
}
function displayDate($date){
	return date("j/m G:i", $date);
}
function longDate($date){
	return date("Y-m-d ", $date);
}
function longDateTime($date){
	return date("Y-m-d G:i ", $date);
}
function userTime($user){          
	$d = new DateTime(date("d F Y H:i:s",time()));
	$d->setTimezone(new DateTimeZone($user['user_timezone']));
	$r =$d->format('G:i');
	return $r;
}
function boomRenderMinutes($val){
	global $lang;
	$day = '';
	$hour = '';
	$minute = '';
	$d = floor ($val / 1440);
	$h = floor (($val - $d * 1440) / 60);
	$m = $val - ($d * 1440) - ($h * 60);
	if($d > 0){
		if($d > 1){ $day = $d . ' ' . $lang['days']; } else{ $day = $d . ' ' . $lang['day']; }
	}
	if($h > 0){
		if($h > 1){ $hour = $h . ' ' . $lang['hours']; } else{ $hour = $h . ' ' . $lang['hour']; }
	}
	if($m > 0){
		if($m > 1){ $minute = $m . ' ' . $lang['minutes']; } else{ $minute = $m . ' ' . $lang['minute']; }
	}
	return trim($day . ' ' . $hour  . ' ' . $minute);
}
function boomRenderSeconds($val){
	global $lang;
	$day = '';
	$hour = '';
	$minute = '';
	$second = '';
	$d = floor ($val / 86400);
	$h = floor (($val - $d * 86400) / 3600);
	$m = floor (($val - ($d * 86400) - ($h * 3600)) / 60);
	$s = $val - ($d * 86400) - ($h * 3600) - ($m * 60);
	if($d > 0){
		if($d > 1){ $day = $d . ' ' . $lang['days']; } else{ $day = $d . ' ' . $lang['day']; } }
	if($h > 0){
		if($h > 1){ $hour = $h . ' ' . $lang['hours']; } else{ $hour = $h . ' ' . $lang['hour']; }
	}
	if($m > 0){
		if($m > 1){ $minute = $m . ' ' . $lang['minutes']; } else{ $minute = $m . ' ' . $lang['minute']; }
	}
	if($s > 0){
		if($s > 1){ $second = $s . ' ' . $lang['seconds']; } else{ $second = $s . ' ' . $lang['second']; }
	}
	return trim($day . ' ' . $hour  . ' ' . $minute . ' ' . $second);
}
function boomTimeLeft($t){
	return boomRenderMinutes(floor(($t - time()) / 60));
}
function boomAllow($rank){
	global $data;
	if($data['user_rank'] >= $rank){
		return true;
	}
}
function userBoomAllow($user, $val){
	if($user['user_rank'] >= $val){
		return true;
	}
}
function boomRole($role){
	global $data;
	if($data['user_role'] >= $role){
		return true;
	}
}
function haveRole($role){
	if($role > 0){
		return true;
	}
}
function isGreater($rank){
	global $data;
	if($data['user_rank'] > $rank){
		return true;
	}
}
function notMe($id){
	global $data;
	if($id != $data['user_id']){
		return true;
	}
}
function isBot($user){
	if($user['user_bot'] > 0){
		return true;
	}
}
function systemBot($user){
	if($user == 9){
		return true;
	}
}
function isSystem($id){
	global $data;
	if($id == $data['system_id']){
		return true;
	}
}
function getTopic($t){
	global $lang;
	$topic = processUserData($t);
	if(!empty($topic)){
		return systemSpecial($topic, 'topic_log', array('icon'=> 'topic.svg', 'title'=> $lang['topic_title']));
	}
}
function boomConsole($target, $type, $custom = array()){
	global $mysqli, $data;
	$def = array(
		'hunter'=> $data['user_id'],
		'room'=> $data['user_roomid'],
		'rank'=> 0,
		'delay'=> 0,
		'reason'=> '',
		'custom' => '',
		'custom2' => '',
	);
	$c = array_merge($def, $custom);
	$mysqli->query("INSERT INTO boom_console (hunter, target, room, ctype, rank, delay, reason, custom, custom2, cdate) VALUES ('{$c['hunter']}', '$target', '{$c['room']}', '$type', '{$c['rank']}', '{$c['delay']}', '{$c['reason']}', '{$c['custom']}', '{$c['custom2']}', '" . time() . "')");
}
function boomHistory($target, $type, $custom = array()){
	global $mysqli, $data;
	$def = array(
		'hunter'=> $data['user_id'],
		'rank'=> 0,
		'delay'=> 0,
		'reason'=> '',
		'content'=> '',
	);
	$c = array_merge($def, $custom);
	$mysqli->query("INSERT INTO boom_history (hunter, target, htype, delay, reason, history_date) VALUES ('{$c['hunter']}', '$target', '$type',  '{$c['delay']}', '{$c['reason']}', '" . time() . "')");
}
function renderReason($t){
	global $lang;
	switch($t){
		case '':
			return $lang['no_reason'];
		case 'badword':
			return $lang['badword'];
		case 'spam':
			return $lang['spam'];
		case 'flood':
			return $lang['flood'];
		default:
			return $t;
	}
}
function userUnmute($user){
	global $mysqli;
	clearNotifyAction($user['user_id'], 'mute');
	$mysqli->query("UPDATE boom_users SET user_mute = 0, mute_msg = '' WHERE user_id = '{$user['user_id']}'");
	boomNotify($user['user_id'], 'unmute', array('source'=> 'mute'));
}
function userUnkick($user){
	global $mysqli;
	$mysqli->query("UPDATE boom_users SET user_kick = 0 WHERE user_id = '{$user['user_id']}'");
}
function muted(){
	global $data;
	if(isMuted($data) || isBanned($data) || isKicked($data) || outChat($data)){
		return true;
	}
}
function roomMuted(){
	global $data;
	if($data['room_mute'] > 0){
		return true;
	}
}
function isRoomMuted($user){
	if($user['room_mute'] > 0){
		return true;
	}
}
function isMuted($user){
	if($user['user_mute'] > time()){
		return true;
	}
}
function mutedData($user){
	if($user['user_mute'] > 0){
		return true;
	}
}
function kickedData($user){
	if($user['user_kick'] > 0){
		return true;
	}
}
function isBanned($user){
	if($user['user_banned'] > 0){
		return true;
	}
}
function isKicked($user){
	if($user['user_kick'] > time()){
		return true;
	}
}
function joinRoom(){
	global $lang, $data;
	if(allowLogs() && isVisible($data)){
		$content = str_replace('%user%', $data['user_name'], $lang['system_join_room']);
		systemPostChat($data['user_roomid'], $content);
	}
}
function leaveRoom(){
	global $data, $lang;
	if(allowLogs()){
		if(isVisible($data) && $data['user_roomid'] != 0 && $data['last_action'] > time() - 30 ){
			$content = str_replace('%user%', $data['user_name'], $lang['quit_room']);
			systemPostChat($data['user_roomid'], $content);
		}
	}
}
function processUserData($t){
	global $data;
	return str_replace(array('%user%'), array($data['user_name']), $t);
}
function roomStaff(){
	if(boomRole(4)){
		return true;
	}
}
function userRoomStaff($rank){
	if($rank >= 4){
		return true;
	}
}
function allowLogs(){
	global $data;
	if($data['allow_logs'] == 1){
		return true;
	}
}
function isVisible($user){
	if($user['user_status'] != 6){
		return true;
	}
}
function isSecure($user){
	if(isEmail($user['user_email'])){
		return true;
	}
}
function isMember($user){
	if(!isGuest($user) && !isBot($user)){
		return true;
	}
}
function isGuest($user){
	if($user['user_rank'] == 0){
		return true;
	}
}
function guestForm(){
	global $data;
	if($data['guest_form'] == 1){
		return true;
	}
}
function strictGuest(){
	global $cody;
	if($cody['strict_guest'] == 1){
		return true;
	}
}
function userDj($user){
	if($user['user_dj'] == 1){
		return true;
	}
}
function boomRecaptcha(){
	global $data;
	if($data['use_recapt'] > 0){
		return true;
	}
}

function encrypt($d){
	return sha1(str_rot13($d . BOOM_CRYPT));
}
function boomEncrypt($d, $encr){
	return sha1(str_rot13($d . $encr));
}
function getDelay(){
	return time() - 35;
}
function getMinutes($t){
	return $t / 60;
}
function isOwner($user){
	if($user['user_rank'] == 11){
		return true;
	}
}
function isStaff($rank){
	if($rank > 7){
		return true;
	}
}
function genKey(){
	return md5(rand(10000,99999) . rand(10000,99999));
}
function genCode(){
	return rand(111111,999999);
}
function genSnum(){
	global $data;
	return $data['user_id'] . rand(1111111, 9999999);
}
function boomUnderClear($t){
	return str_replace('_', ' ', $t);
}
function allowGuest(){
	global $data;
	if($data['allow_guest'] == 1){
		return true;
	}
}
function roomName(){
	global $mysqli, $data;
	$groom = $mysqli->query("SELECT room_name FROM boom_rooms WHERE room_id = '{$data['user_roomid']}'");
	$r = $groom->fetch_assoc();
	return $r['room_name'];
}
function boomMerge($a, $b){
	$c = $a . '_' . $b;
	return trim($c);
}
function clearNotifyAction($id, $type){
	global $mysqli;
	$mysqli->query("DELETE FROM boom_notification WHERE notified = '$id' AND notify_source = '$type'");
}
function setToken(){
	global $cody;
	if(!empty($_SESSION[BOOM_PREFIX . 'token'])){
		$_SESSION[BOOM_PREFIX . 'token'] = $_SESSION[BOOM_PREFIX . 'token'];
		return $_SESSION[BOOM_PREFIX . 'token'];
	}
	else {
		$session = md5(rand(000000,999999));
		$_SESSION[BOOM_PREFIX . 'token'] = $session;
		return $session;
	}
}
function boomDuplicateIp($val){
	global $mysqli, $data, $cody;
	$dupli = $mysqli->query("SELECT * FROM `boom_banned` WHERE `ip` = '$val'");
	if($dupli->num_rows > 0){
		return true;
	}
}
function checkToken() {
	global $cody;
    if (!isset($_POST['token']) || !isset($_SESSION[BOOM_PREFIX . 'token']) || empty($_SESSION[BOOM_PREFIX . 'token'])) {
        return false;
    }
	if($_POST['token'] == $_SESSION[BOOM_PREFIX . 'token']){
		return true;
	}
    return false;
}

// ranking functions

function mutedIcon($user, $c){
	global $lang;
	if(isMuted($user)){
		return '<img title="' . $lang['muted'] . '" class="' . $c . '" src="default_images/actions/muted.svg"/>';
	}
	else if(isRoomMuted($user)){
		return '<img title="' . $lang['muted'] . '" class="' . $c . '" src="default_images/actions/room_muted.svg"/>';
	}
	else {
		return '';
	}
}

// sex and gender functions

function listGender($sex){
	global $lang;
	$list = '';
	$list .= '<option ' . selCurrent($sex, 1) . ' value="1">' . $lang['male'] . '</option>';
	$list .= '<option ' . selCurrent($sex, 2) . ' value="2">' . $lang['female'] . '</option>';
	$list .= '<option ' . selCurrent($sex, 3) . ' value="3">' . $lang['other'] . '</option>';
	return $list;
}
function boomValidGender($sex){
	$gender = array(1,2,3);
	if(in_array($sex, $gender)){
		return true;
	}
}
function getGender($s){
	global $lang;
	switch($s){
		case 1:
			return $lang['male'];
		case 2:
			return $lang['female'];
		case 3:
			return $lang['other'];
		default:
			return $lang['not_set'];
	}
}
function sex($s){
	global $lang;
	switch($s){
		case 1:
			return 'boy';
		case 2:
			return 'girl';
		case 3:
			return 'nosex';
		default:
			return 'nosex';
	}
}

// status functions

function getStatus($status, $c){
	global $lang;
	switch($status){
		case 2:
			return curStatus($lang['away'], 'away.svg', $c);
		case 3:
			return curStatus($lang['busy'], 'busy.svg', $c);
		default:
			return '';
	}
}
function curStatus($txt, $icon, $c){
	return '<img title="' . $txt . '" class="' . $c . '" src="default_images/status/' . $icon . '"/>';	
}
function listStatus($status){
	global $lang;
	switch($status){
		case 1:
			return statusMenu($lang['online'], 'online.svg');
		case 2:
			return statusMenu($lang['away'], 'away.svg');
		case 3:
			return statusMenu($lang['busy'], 'busy.svg');
		case 6:
			return statusMenu($lang['invisible'], 'invisible.svg');
		default:
			return statusMenu($lang['online'], 'online.svg');
	}
}
function statusMenu($txt, $icon){
	return '<div class="status_icon"><img src="default_images/status/' . $icon . '"/></div><div class="status_text">' . $txt . '</div>';
}
function listAllStatus(){
	global $lang, $data, $cody;
	$list = '';
	$list .= statusBox(1, listStatus(1));	
	$list .= statusBox(2, listStatus(2));
	$list .= statusBox(3, listStatus(3));
	if(canInvisible()){
		$list .= statusBox(6, listStatus(6));
	}
	return $list;
}
function statusBox($value, $content){
	return '<div class="status_option" data="' . $value . '">' . $content . '</div>';
}

// system ranking functions

function rankIcon($list, $type){
	if(isBot($list)){
		return botRank($type);
	}
	else if(haveRole($list['user_role']) && !isStaff($list['user_rank'])){
		return roomRank($list['user_role'], $type);
	}
	else {
		return systemRank($list['user_rank'], $type);
	}
}
function botRank($type){
	global $lang;
	return curRanking($type, $lang['user_bot'], 'bot.svg');
}
function systemRank($rank, $type){
	global $lang;
	switch($rank){
		case 2:
			return curRanking($type, $lang['vip'], 'vip.svg');
		case 8:
			return curRanking($type, $lang['mod'], 'mod.svg');
		case 9:
			return curRanking($type, $lang['admin'], 'admin.svg');
		case 10:
			return curRanking($type, $lang['super_admin'], 'super.svg');
		case 11:
			return curRanking($type, $lang['owner'], 'owner.svg');
		default:
			return '';
	}
}
function proRanking($user, $type){
	global $lang;
	if(isBot($user)){
		return proRank($type, $lang['user_bot'], 'bot.svg');
	}
	else {
		switch($user['user_rank']){
			case 0:
				return proRank($type, $lang['guest'], 'guest.svg');
			case 1:
				return proRank($type, $lang['user'], 'user.svg');
			case 2:
				return proRank($type, $lang['vip'], 'vip.svg');
			case 8:
				return proRank($type, $lang['mod'], 'mod.svg');
			case 9:
				return proRank($type, $lang['admin'], 'admin.svg');
			case 10:
				return proRank($type, $lang['super_admin'], 'super.svg');
			case 11:
				return proRank($type, $lang['owner'], 'owner.svg');
			default:
				return '';
		}
	}
}
function roomRank($rank, $type){
	global $lang;
	switch($rank){
		case 6:
			return curRanking($type, $lang['r_owner'], 'room_owner.svg');
		case 5:
			return curRanking($type, $lang['r_admin'], 'room_admin.svg');
		case 4:
			return curRanking($type, $lang['r_mod'], 'room_mod.svg');
	}
}
function curRanking($type, $txt, $icon){
	return '<img src="default_images/rank/' . $icon . '" class="' . $type . '" title="' . $txt . '"/>';
}
function proRank($type, $txt, $icon){
	return '<img src="default_images/rank/' . $icon . '" class="' . $type . '"/> ' . $txt;
}

function getRank($rank){
	global $lang;
	switch($rank){
		case 0:
			return $lang['guest'];
		case 1:
			return $lang['user'];
		case 2:
			return $lang['vip'];
		case 8:
			return $lang['mod'];
		case 9:
			return $lang['admin'];
		case 10:
			return $lang['super_admin'];
		case 11:
			return $lang['owner'];
		default:
			return $lang['user'];
	}
}
function roomTitle($rank){
	global $lang;
	switch($rank){
		case 6:
			return $lang['r_owner'];
		case 5:
			return $lang['r_admin'];
		case 4:
			return $lang['r_mod'];
		default:
			return $lang['user'];
	}
}
function listRank($current, $req = 0){
	global $lang, $data;
	$rank = '';
	if($req == 1){
		$rank .= '<option value="0" ' . selCurrent($current, 0) . '>' . $lang['guest'] . '</option>';
	}
	$rank .= '<option value="1" ' . selCurrent($current, 1) . '>' . $lang['user'] . '</option>';
	$rank .= '<option value="2" ' . selCurrent($current, 2) . '>' . $lang['vip'] . '</option>';
	$rank .= '<option value="8" ' . selCurrent($current, 8) . '>' . $lang['mod'] . '</option>';
	$rank .= '<option value="9" ' . selCurrent($current, 9) . '>' . $lang['admin'] . '</option>';
	$rank .= '<option value="10" ' . selCurrent($current, 10) . '>' . $lang['super_admin'] . '</option>';
	$rank .= '<option value="11" ' . selCurrent($current, 11) . '>' . $lang['owner'] . '</option>';
	return $rank;
}
function changeRank($current){
	global $lang, $data;
	$rank = '';
	if(boomAllow(9)){
		$rank .= '<option value="1" ' . selCurrent($current, 1) . '>' . $lang['user'] . '</option>';
		$rank .= '<option value="2" ' . selCurrent($current, 2) . '>' . $lang['vip'] . '</option>';
		$rank .= '<option value="8" ' . selCurrent($current, 8) . '>' . $lang['mod'] . '</option>';
	}
	if(boomAllow(10)){
		$rank .= '<option value="9" ' . selCurrent($current, 9) . '>' . $lang['admin'] . '</option>';
	}
	if(boomAllow(11)){
		$rank .= '<option value="10" ' . selCurrent($current, 10) . '>' . $lang['super_admin'] . '</option>';
	}
	return $rank;
}
function listRoomRank($current = 0){
	global $lang, $data;
	$rank = '';
	$rank .= '<option value="0" ' . selCurrent($current, 0) . '>' . $lang['none'] . '</option>';
	$rank .= '<option value="4" ' . selCurrent($current, 4) . '>' . $lang['r_mod'] . '</option>';
	$rank .= '<option value="5" ' . selCurrent($current, 5) . '>' . $lang['r_admin'] . '</option>';
	if(boomAllow(9)){
		$rank .= '<option value="6" ' . selCurrent($current, 6) . '>' . $lang['r_owner'] . '</option>';
	}
	return $rank;
}

// room access ranking functions

function roomRanking($rank = 0){
	global $lang;
	$room_menu = '<option value="0" ' . selCurrent($rank, 0) . '>' . $lang['public'] . '</option>';
	if(boomAllow(1)){
		$room_menu .= '<option value="1" ' . selCurrent($rank, 1) . '>' . $lang['members'] . '</option>';
	}
	if(boomAllow(2)){ 
		$room_menu .= '<option value="2" ' . selCurrent($rank, 2) . '>' . $lang['vip'] . '</option>';
	}
	if(boomAllow(8)){ 
		$room_menu .= '<option value="8" ' . selCurrent($rank, 8) . '>' . $lang['staff'] . '</option>';
	}
	if(boomAllow(9)){ 
		$room_menu .= '<option value="9" ' . selCurrent($rank, 9) . '>' . $lang['admin'] . '</option>';
	}
	return $room_menu;
}
function roomIcon($room, $type){
	global $lang;
	switch($room['access']){
		case 0:
			return roomIconTemplate($type, $lang['public'], 'public_room.svg');
		case 1:
			return roomIconTemplate($type, $lang['members'], 'member_room.svg');
		case 2:
			return roomIconTemplate($type, $lang['vip'], 'vip_room.svg');
		case 8:
			return roomIconTemplate($type, $lang['staff'], 'staff_room.svg');
		case 9:
			return roomIconTemplate($type, $lang['admin'], 'admin_room.svg');
		default:
			return roomIconTemplate($type, $lang['public'], 'public_room.svg');
	}
}
function roomIconTemplate($type, $txt, $icon){
	global $data;
	return '<img title="' . $txt . '" class="' . $type .  '" src="' . $data['domain'] . '/default_images/rooms/' . $icon . '">';	
}
function roomAccessTitle($room){
	global $lang;
	switch($room['access']){
		case 0:
			return $lang['public'];
		case 1:
			return $lang['members'];
		case 2:
			return $lang['vip'];
		case 8:
			return $lang['staff'];
		case 9:
			return $lang['admin'];
		default:
			return $lang['public'];
	}
}
function roomLock($room, $type){
	global $data, $lang;
	if($room['password'] != ''){
		return '<img title="' . $lang['password'] . '" class="' . $type .  '" src="' . $data['domain'] . '/default_images/rooms/locked_room.svg">';
	}
}

// permission functions

function canEditRoom(){
	if(boomRole(6) || boomAllow(9)){
		return true;
	}
}
function canManageRoom(){
	if(boomRole(4) || boomAllow(9)){
		return true;
	}
}
function canUpload(){
	global $data;
	if(boomAllow($data['allow_image'])){
		return true;
	}
}
function canCover(){
	global $data;
	if(boomAllow($data['allow_cover'])){
		return true;
	}
}
function canGifCover(){
	global $data;
	if(boomAllow($data['allow_gcover'])){
		return true;
	}
}
function canPrivate(){
	global $data;
	if(boomAllow($data['allow_private'])){
		return true;
	}
}
function userCanPrivate($user){
	global $data;
	if(userBoomAllow($user, $data['allow_private'])){
		return true;
	}
}
function canRoom(){
	global $data;
	if(boomAllow($data['allow_room'])){
		return true;
	}
}
function canPlayer(){
	global $data;
	if(boomAllow($data['allow_player'])){
		return true;
	}
}
function canEmo(){
	global $data;
	if(boomAllow($data['emo_plus'])){
		return true;
	}
}
function canName(){
	global $data;
	if(boomAllow($data['allow_name'])){
		return true;
	}
}
function canDirect(){
	global $data;
	if(boomAllow($data['allow_direct'])){
		return true;
	}
}
function userCanDirect($user){
	global $data;
	if(userBoomAllow($user, $data['allow_direct'])){
		return true;
	}
}
function canColor(){
	global $data;
	if(boomAllow($data['allow_colors'])){
		return true;
	}
}
function canGrad(){
	global $data;
	if(boomAllow($data['allow_grad'])){
		return true;
	}
}
function canMood(){
	global $data;
	if(boomAllow($data['allow_mood'])){
		return true;
	}
}
function canVerify(){
	global $data;
	if(boomAllow($data['allow_verify'])){
		return true;
	}
}
function canHistory(){
	global $data;
	if(boomAllow($data['allow_history'])){
		return true;
	}
}
function canAvatar(){
	global $data;
	if(boomAllow($data['allow_avatar'])){
		return true;
	}
}
function canTheme(){
	global $data;
	if(boomAllow($data['allow_theme'])){
		return true;
	}
}
function canNameColor(){
	global $data;
	if(boomAllow($data['allow_name_color'])){
		return true;
	}
}
function canNameGrad(){
	global $data;
	if(boomAllow($data['allow_name_grad'])){
		return true;
	}
}
function canInvisible(){
	global $data, $cody;
	if(boomAllow($cody['can_invisible'])){
		return true;
	}
}
function canPostNews(){
	global $data, $cody;
	if(boomAllow($cody['can_post_news'])){
		return true;
	}
}
function canModifyAvatar($user){
	global $data, $cody;
	if(!empty($user) && canAvatar() && canEditUser($user, $cody['can_modify_avatar'])){
		return true;
	}
}
function canModifyCover($user){
	global $data, $cody;
	if(!empty($user) && canCover() && canEditUser($user, $cody['can_modify_cover'])){
		return true;
	}
}
function canModifyName($user){
	global $data, $cody;
	if(!empty($user) && canName() && canEditUser($user, $cody['can_modify_name'])){
		return true;
	}
}
function canModifyMood($user){
	global $data, $cody;
	if(!empty($user) && canMood() && canEditUser($user, $cody['can_modify_mood'])){
		return true;
	}
}
function canModifyAbout($user){
	global $data, $cody;
	if(!empty($user) && canEditUser($user, $cody['can_modify_about'])){
		return true;
	}
}
function canModifyEmail($user){
	global $data, $cody;
	if(!empty($user) && isMember($user) && isSecure($user) && canEditUser($user, $cody['can_modify_email'], 1)){
		return true;
	}
}
function canModifyColor($user){
	global $data, $cody;
	if(!empty($user) && canNameColor() && canEditUser($user, $cody['can_modify_color'])){
		return true;
	}
}
function canModifyPassword($user){
	global $data, $cody;
	if(!empty($user) && isMember($user) && isSecure($user) && canEditUser($user, $cody['can_modify_password'], 1)){
		return true;
	}
}
function canUserHistory($user){
	global $data, $cody;
	if(!empty($user) && canEditUser($user, $cody['can_view_history'], 1)){
		return true;
	}
}
function canViewTimezone($user){
	global $data, $cody;
	if(canEditUser($user, $cody['can_view_timezone'], 1)){
		return true;
	}
}
function canViewEmail($user){
	global $data, $cody;
	if(userHaveEmail($user) && canEditUser($user, $cody['can_view_email'], 1)){
		return true;
	}
}
function canViewId($user){
	global $data, $cody;
	if(canEditUser($user, $cody['can_view_id'], 1)){
		return true;
	}
}
function canViewIp($user){
	global $data, $cody;
	if(canEditUser($user, $cody['can_view_ip'], 1)){
		return true;
	}
}
function canRoomPassword(){
	global $data, $cody;
	if(boomAllow($cody['can_room_pass']) || boomRole(6)){
		return true;
	}
}
function canBan(){
	global $data, $cody;
	if(boomAllow($cody['can_ban'])){
		return true;
	}
}
function canBanUser($user){
	global $data, $cody;
	if(!empty($user) && canEditUser($user, $cody['can_ban'], 1)){ 
		return true;
	}
}
function canKick(){
	global $data, $cody;
	if(boomAllow($cody['can_kick'])){
		return true;
	}
}
function canKickUser($user){
	global $data, $cody;
	if(!empty($user) && canEditUser($user, $cody['can_kick'], 1)){ 
		return true;
	}
}
function canDeleteNews(){
	global $data, $cody;
	if(boomAllow(11)){
		return true;
	}
}
function canDeleteWall(){
	global $data, $cody;
	if(boomAllow(8)){
		return true;
	}
}
function canDeleteLog(){
	global $data, $cody;
	if(boomAllow(8)){
		return true;
	}
}
function canDeleteRoomLog(){
	global $data, $cody;
	if(boomRole(4)){
		return true;
	}
}
function canClearRoom(){
	global $data, $cody;
	if(boomAllow(8) || boomRole(5)){
		return true;
	}
}

// DO NOT MODIFY THE MUTE PERMISSION THIS WILL MAKE CONFLICT IN THE SYSTEM.

function canMute(){
	global $data, $cody;
	if(boomAllow(8)){
		return true;
	}
}
function canMuteUser($user){
	global $data, $cody;
	if(!empty($user) && canEditUser($user, 8, 1)){ 
		return true;
	}
}
?>