<div class="up_file">
	<div class="up_file_inside">
		<img src="<?php echo $boom['image']; ?>"/>
		<div class="up_file_remove olay" onclick="removeFile('<?php echo $boom['encrypt']; ?>');">
			<i class="fa fa-times"></i>
		</div>
	</div>
</div>