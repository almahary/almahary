<div class="modal_top">
	<div class="modal_top_empty">
		<?php echo $boom; ?>
	</div>
	<div class="modal_top_element close_modal">
		<i class="fa fa-times"></i>
	</div>
</div>