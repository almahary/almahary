<?php
$report_message = '';
$reason = '';
$add_link = '';
if($boom['report_type'] == 1){
	$report_message = $lang['reported_chat'];
	$add_link = 'onclick="showPostReport(\'' . $boom['report_post'] . '\', \'1\', this);"';
	$class = 'crep' . $boom['report_post'];
}
if($boom['report_type'] == 2){
	$report_message = $lang['reported_post'];
	$add_link = 'onclick="showPostReport(\'' . $boom['report_post'] . '\', \'2\', this);"';
	$class = 'prep' . $boom['report_post'];
}
switch ($boom['report_reason']) {
	case 'language':
		$reason = $lang['report_language'];
		break;
	case 'content':
		$reason = $lang['report_content'];
		break;
	case 'spam':
		$reason = $lang['report_spam'];
		break;

}
?>
<div <?php echo $add_link; ?> class="<?php echo $class; ?> list_element notify_item">
	<div class="notify_avatar">
		<img src="<?php echo myavatar($boom['user_tumb']); ?>"/>
	</div>
	<div class="notify_details">
		<p class="hnotify username <?php echo $boom['user_color']; ?>"><?php echo $boom['user_name']; ?></p>
		<p class="notify_text" ><?php echo $lang['reported_reason']; ?> : <?php echo $reason; ?></p>
		<p class="text_xsmall date date_notify"><?php echo displayDate($boom['report_date']); ?></p>
	</div>
</div>