<div class="empty_zone">
	<p class="empty_zone_icon text_jumbo sub_text bpad5"><i class="fa fa-<?php echo $boom['icon']; ?>"></i></p>
	<p class="empty_zone_text text_small sub_text"><?php echo $boom['text']; ?></p>
</div>