<div data="<?php echo $boom['load']; ?>" class="get_dat page_drop_item">
	<div class="page_drop_text"><?php echo $boom['txt']; ?></div>
</div>