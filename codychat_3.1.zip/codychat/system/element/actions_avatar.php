<div data="" value="" data-av=""  class="avitem gprivate avpriv">
	<span class="list_icon"><i class="fa fa-comments theme_color"></i></span><?php echo $lang['private_chat']; ?>
</div>
<div data="" value="" data-av="" class="avitem get_info avglobal">
	<span class="list_icon"><i class="fa fa-user-circle-o default_color"></i></span><?php echo $lang['info']; ?>
</div>
<div data="" value="" data-av="" class="avitem get_actions avactions">
	<span class="list_icon"><i class="fa fa-flash error"></i></span><?php echo $lang['do_action']; ?>
</div>