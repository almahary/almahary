<?php
// you can edit these lines to configure new setting for your chat
$DB_HOST = "";
$DB_USER = "";
$DB_PASS = "";
$DB_NAME = "";

// Please do not modify this line post installation
$encryption = "";
$check_install = 0;
?>