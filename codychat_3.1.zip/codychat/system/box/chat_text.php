<?php
require_once('../config_session.php');
if(!canColor()){
	die();
}
?>
<div class="pad_box">
	<div class="color_choices" data="<?php echo $data['bccolor']; ?>">
			<?php if(canGrad()){ ?>
			<div class="reg_menu_container">		
				<div class="reg_menu">
					<ul>
						<li class="reg_menu_item reg_selected" data="color_tab" data-z="reg_color"><?php echo $lang['color']; ?></li>
						<li class="reg_menu_item" data="color_tab" data-z="grad_color"><?php echo $lang['gradient']; ?></li>
					</ul>
				</div>
			</div>
			<?php } ?>
			<div id="color_tab">
				<div id="reg_color" class="reg_zone vpad5">
					<?php echo colorChoice($data['bccolor'], 2); ?>
					<div class="clear"></div>
				</div>
				<?php if(canGrad()){ ?>
				<div id="grad_color" class="reg_zone vpad5 hide_zone">
					<?php echo gradChoice($data['bccolor'], 2); ?>
					<div class="clear"></div>
				</div>
				<?php } ?>
			</div>
	</div>
	<div class="clear"></div>
	<button id="boldit" data="<?php echo $data['bcbold']; ?>" class="small_button bold <?php echo boldIt($data['bcbold']); ?>"><?php echo $lang['bold']; ?></button>
	<div class="clear"></div>
</div>