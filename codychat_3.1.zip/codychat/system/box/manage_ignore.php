<?php
require('../config_session.php');
?>
<div class="pad15 ulist_container">
	<?php echo myIgnore(); ?>
</div>