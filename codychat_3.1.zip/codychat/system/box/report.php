<?php
require_once('../config_session.php');

if(!isset($_POST['type'], $_POST['id'])){
	die();
}
$id = escape($_POST['id']);
$type = escape($_POST['type']);

if(!canReport($data)){
	echo 3;
	die();
}
?>
<div class="pad15">
	<div class="btable vpad10" id="report_option" data-r="">
		<div class="report_item"><div onclick="sReport(this,'language');" class="report_check"><i class="rcheck fa fa-circle-thin"></i></div><div class="report_text"><?php echo $lang['report_language']; ?></div></div>
		<div class="report_item"><div onclick="sReport(this,'spam');" class="report_check"><i class="rcheck fa fa-circle-thin"></i></div><div class="report_text"><?php echo $lang['report_spam']; ?></div></div>
		<div class="report_item"><div onclick="sReport(this,'content');" class="report_check"><i class="rcheck fa fa-circle-thin"></i></div><div class="report_text"><?php echo $lang['report_content']; ?></div></div>
	</div>
	<button id="report_post" onclick="makeReport(<?php echo $id; ?>, <?php echo $type; ?>);" class="reg_button theme_btn"><?php echo $lang['report']; ?></button>
	<button class="default_btn reg_button cancel_over"><?php echo $lang['cancel']; ?></button>
</div>