<?php
require('../config_session.php');

if(!isset($_POST['get_profile'], $_POST['cp'])){
	die();
}
$id = escape($_POST['get_profile']);
$curpage = escape($_POST['cp']);
$user = userRoomDetails($id);
if(empty($user)){
	echo 2;
	die();
}
?>
<div class="modal_wrap_top modal_top">
	<div class="btable profile_top profile_background <?php echo coverClass($user); ?>" <?php echo getCover($user); ?>>
		<div id="proav" class="profile_avatar" data="<?php echo $user['user_tumb']; ?>" >
			<div class="avatar_spin">
				<img class="fancybox avatar_profile" <?php echo profileAvatar($user['user_tumb']); ?>/>
				<div class="rank_profile_tag dark_olay">
					<p class="bellips text_xsmall"><?php echo proRanking($user, 'pro_ranking'); ?></p>
				</div>
			</div>
		</div>
		<div class="profile_tinfo cover_text">
			<div class="pdetails">
				<div class="pdetails_text pro_name">
					<?php echo $user['user_name']; ?>
				</div>
			</div>
			<div class="pdetails">
				<?php if(!empty($user['user_mood'])){ ?>
				<div class="pdetails_text pro_mood bellips">
					<?php echo $user['user_mood']; ?>
				</div>
				<?php } ?>
			</div>
			<div class="pdetails">
				<div class="bcell">
				<?php if(notMe($user['user_id']) && !isBot($user)){ ?>
				<button onclick="getActions(<?php echo $user['user_id']; ?>);" class="tiny_button ok_btn "><i class="fa fa-bolt"></i> <span class="hide_phone"><?php echo $lang['do_action']; ?></span></button>
				<?php } ?>
				<?php if(notMe($user['user_id']) && canPrivate() && userCanPrivate($user) && !ignored($user) && insideChat($curpage)){ ?>
				<button data="<?php echo $user['user_id']; ?>" value="<?php echo $user['user_name']; ?>" data-av="<?php echo myAvatar($user['user_tumb']); ?>" class="gprivate tiny_button theme_btn "><i class="fa fa-comments"></i> <span class="hide_phone"><?php echo $lang['private_chat']; ?></span></button>
				<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="modal_top_menu">
		<div class="cancel_modal cover_text modal_top_item">
			<i class="fa fa-times"></i>
		</div>
	</div>
</div>
<?php if(isMuted($user) && !isBanned($user)){ ?>
<div class="im_muted profile_info_box warn_btn">
	<i class="fa fa-exclamation-circle"></i> <?php echo $lang['user_muted']; ?>
</div>
<?php } ?>
<?php if(isBanned($user)){ ?>
<div class="im_banned profile_info_box delete_btn">
	<i class="fa fa-exclamation-circle"></i> <?php echo $lang['user_banned']; ?>
</div>
<?php } ?>
<div class="modal_menu">
	<ul>
		<li class="modal_menu_item modal_selected" data="mprofilemenu" data-z="profile_info"><?php echo $lang['about_me']; ?></li>
		<?php if(!isGuest($user) && !isBot($user)){ ?>
		<li class="modal_menu_item" data="mprofilemenu" onclick="lazyBoom('profile_friends');" data-z="profile_friends"><?php echo $lang['friends']; ?></li>
		<?php } ?>
		<?php if(boomAllow(0) && !isBot($user)){ ?> 
		<li class="modal_menu_item" data="mprofilemenu" data-z="prodetails"><?php echo $lang['main_info']; ?></li>
		<?php } ?>
		<?php if(canEditUser($user, 8)){ ?>
		<li class="modal_menu_item" data="mprofilemenu" data-z="void" onclick="editUser(<?php echo $user['user_id']; ?>);"><?php echo $lang['edit']; ?></li>
		<?php } ?>
	</ul>
</div>
<div id="mprofilemenu">
	<div class="modal_zone pad25 tpad15" id="profile_info">
		<div class="clearbox">
			<?php if(boomAge($user['user_age'])){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['age']; ?></div>
				<div class="listing_text"><?php echo getUserAge($user['user_age']); ?></div>
			</div>
			<?php } ?>
			<?php if(boomSex($user['user_sex'])){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['gender']; ?></div>
				<div class="listing_text"><?php echo getGender($user['user_sex']); ?></div>
			</div>
			<?php } ?>
			<?php if(verified($user)){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['account_status']; ?></div>
				<div class="listing_text"><?php echo $lang['verified']; ?></div>
			</div>
			<?php } ?>
			<?php if(usercountry($user['country'])){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['country']; ?></div>
				<div class="listing_text"><?php echo countryName($user['country']); ?></div>
			</div>
			<?php } ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['join_chat']; ?></div>
				<div class="listing_text"><?php echo longDate($user['user_join']); ?></div>
			</div>
		</div>
		<?php if($user['user_about'] != ''){ ?>
		<div>
			<div class="listing_element info_pro">
				<div class="listing_title"><?php echo $lang['about_me']; ?></div>
				<div class="listing_text"><?php echo boomFormat($user['user_about']); ?></div>
			</div>
		</div>
		<?php } ?>
	</div>
	<?php if(!isBot($user)){ ?>
	<div class="hide_zone  pad25 tpad15 modal_zone" id="prodetails">
		<div class="clearbox">
			<?php if(isVisible($user)){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['last_seen']; ?></div>
				<div class="listing_text"><?php echo longDateTime($user['last_action']); ?></div>
			</div>
			<?php } ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['language']; ?></div>
				<div class="listing_text"><?php echo $user['user_language']; ?></div>
			</div>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['user_theme']; ?></div>
				<div class="listing_text"><?php echo boomUserTheme($user); ?></div>
			</div>
			<?php if(canViewTimezone($user)){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['user_timezone']; ?></div>
				<div class="listing_text"><?php echo userTime($user); ?></div>
			</div>
			<?php } ?>
			<?php if(canViewEmail($user)){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['email']; ?></div>
				<div class="listing_text"><?php echo $user['user_email']; ?></div>
			</div>
			<?php } ?>
			<?php if(canViewIp($user)){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['ip']; ?></div>
				<div class="listing_text"><?php echo $user['user_ip']; ?></div>
			</div>
			<?php } ?>
			<?php if(canViewId($user)){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['user_id']; ?></div>
				<div class="listing_text"><?php echo $user['user_id']; ?></div>
			</div>
			<?php } ?>
			<?php if(canEditUser($user, 8, 1)){ ?>
			<div class="listing_half_element info_pro">
				<div class="listing_title"><?php echo $lang['other_account']; ?></div>
				<div class="listing_text"><?php echo sameAccount($user); ?></div>
			</div>
			<?php } ?>
		</div>
	</div>
	<?php } ?>
	<?php if(!isGuest($user) && !isBot($user)){ ?>
	<div class="hide_zone pad20 modal_zone" id="profile_friends">
		<?php echo findFriend($user); ?>
		<div class="clear"></div>
	</div>
	<?php } ?>
</div>