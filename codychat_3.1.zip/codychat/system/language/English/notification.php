<?php
$nlang['like'] = 'Has reacted to one of your post';
$nlang['reply'] = 'Commented on one of your post';
$nlang['add_post'] = 'Posted something on the wall';
$nlang['accept_friend'] = 'Has accepted your friend request';
$nlang['word_mute'] = 'You have been muted %delay% using prohibited words';
$nlang['flood_mute'] = 'Your account has been muted %delay% for flooding';
$nlang['spam_mute'] = 'You have been muted %delay% for spamming';
$nlang['rank_change'] = 'Your rank has been changed you are now %rank%';
$nlang['mute'] = 'You have been muted for %delay%';
$nlang['unmute'] = 'You have been unmuted';
$nlang['name_change'] = 'Has changed your username for %data%';
?>