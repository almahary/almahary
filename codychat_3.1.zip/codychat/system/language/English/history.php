<?php
$hlang['flood_mute'] = 'Flood mute';
$hlang['word_mute'] = 'Word mute';
$hlang['word_kick'] = 'Word kick';
$hlang['spam_mute'] = 'Spam mute';
$hlang['spam_ban'] = 'Spam ban';
$hlang['mute'] = 'Mute';
$hlang['ban'] = 'Ban';
$hlang['kick'] = 'Kick';
?>