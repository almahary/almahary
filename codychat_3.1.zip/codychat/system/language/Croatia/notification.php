<?php
$nlang['like'] = 'Reagirao/la je na jednu vašu objavu';
$nlang['reply'] = 'Korisnik je komentarisao/la jedanu vašu objavu';
$nlang['add_post'] = 'Objavio/la nešto na zidu';
$nlang['accept_friend'] = 'Prihvatio/la je zahtjev za prijateljstvo';
$nlang['word_mute'] = 'Trenutno imate zabranu %delay% razlog loš riječnik';
$nlang['flood_mute'] = 'Vaš korisnički račun je zabranjen %delay% zbog nedozvoljene akcije flodanje';
$nlang['spam_mute'] = 'Trenutno imate zabranu %delay% razlog spamovanje';
$nlang['rank_change'] = 'Vaš čin je promjenjen i trenutno imate novi čin %rank%';
$nlang['mute'] = 'Trenutno imate zabranu za konverzaciju %delay%';
$nlang['unmute'] = 'Vaš korisnički račun je odblokiran za konverzaciju';
$nlang['name_change'] = 'je promjenio/la vaše korisničko ime na %data%';
?>