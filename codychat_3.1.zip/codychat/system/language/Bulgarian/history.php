<?php
$hlang['flood_mute'] = 'Заглушен/а заради спам';
$hlang['word_mute'] = 'Заглушен/а заради лоши думи';
$hlang['word_kick'] = 'Изритан/а заради лоши думи';
$hlang['spam_mute'] = 'Заглуши заради спам';
$hlang['spam_ban'] = 'Бан за спам';
$hlang['mute'] = 'Заглуши';
$hlang['ban'] = 'Бан';
$hlang['kick'] = 'Изритай';
?>