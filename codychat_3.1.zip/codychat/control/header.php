<div id="header2" class="background_header">
	<div id="wrap_main_header">
		<div id="main_header" class="out_head headers">
			<?php if($page['page_menu'] == 1){ ?>
				<div id="open_sub_mobile"><i class="fa fa-bars"></i></div>
			<?php } ?>
			<?php if(!embedMode()){ ?>
			<div class="head_logo">
				<img id="main_logo" alt="logo" src="<?php echo getLogo('logo'); ?>"/>
			</div>
			<?php } ?>
			<div id="empty_top_mob" class="bcell_mid hpad10">
			</div>
			<?php if($page['page_nohome'] == 0){ ?>
			<div onclick="openSamePage('<?php echo $data['domain']; ?>');" class="head_option">
				<i class="i_btm fa fa-home"></i>
			</div>
			<?php } ?>
			<?php if(boomLogged()){?>
			<div onclick="showMenu('mobile_main_menu');" id="main_mob_menu" class="bclick">
				<img class="glob_av avatar_menu" src="<?php echo myavatar($data['user_tumb']); ?>"/>
				<div id="mobile_main_menu" class="hideall sub_menu">
					<div class="sub_menu_item" onclick="editProfile();">
						<div class="sub_menu_icon">
							<i class="fa fa-user-circle"></i>
						</div>
						<div class="sub_menu_text">
							<?php echo $lang['my_profile']; ?>
						</div>
					</div>
					<?php if($page['page'] != 'admin' && boomAllow(8)){ ?>
					<div class="sub_menu_item" onclick="openLinkPage('admin.php');">
						<div class="sub_menu_icon">
							<i class="fa fa-dashboard"></i>
						</div>
						<div class="sub_menu_text">
							<?php echo $lang['admin_panel']; ?>
						</div>
					</div>
					<?php } ?>
					<div class="sub_menu_item" id="open_logout" onclick="openLogout();">
						<div class="sub_menu_icon">
							<i class="fa fa-sign-out"></i>
						</div>
						<div class="sub_menu_text">
							<?php echo $lang['logout']; ?>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
</div>
<div class="empty_subhead">
</div>